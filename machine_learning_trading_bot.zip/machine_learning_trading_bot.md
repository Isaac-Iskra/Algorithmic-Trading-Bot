# Machine Learning Trading Bot

In this Challenge, you’ll assume the role of a financial advisor at one of the top five financial advisory firms in the world. Your firm constantly competes with the other major firms to manage and automatically trade assets in a highly dynamic environment. In recent years, your firm has heavily profited by using computer algorithms that can buy and sell faster than human traders.

The speed of these transactions gave your firm a competitive advantage early on. But, people still need to specifically program these systems, which limits their ability to adapt to new data. You’re thus planning to improve the existing algorithmic trading systems and maintain the firm’s competitive advantage in the market. To do so, you’ll enhance the existing trading signals with machine learning algorithms that can adapt to new data.

## Instructions:

Use the starter code file to complete the steps that the instructions outline. The steps for this Challenge are divided into the following sections:

* Establish a Baseline Performance

* Tune the Baseline Trading Algorithm

* Evaluate a New Machine Learning Classifier

* Create an Evaluation Report

#### Establish a Baseline Performance

In this section, you’ll run the provided starter code to establish a baseline performance for the trading algorithm. To do so, complete the following steps.

Open the Jupyter notebook. Restart the kernel, run the provided cells that correspond with the first three steps, and then proceed to step four. 

1. Import the OHLCV dataset into a Pandas DataFrame.

2. Generate trading signals using short- and long-window SMA values. 

3. Split the data into training and testing datasets.

4. Use the `SVC` classifier model from SKLearn's support vector machine (SVM) learning method to fit the training data and make predictions based on the testing data. Review the predictions.

5. Review the classification report associated with the `SVC` model predictions. 

6. Create a predictions DataFrame that contains columns for “Predicted” values, “Actual Returns”, and “Strategy Returns”.

7. Create a cumulative return plot that shows the actual returns vs. the strategy returns. Save a PNG image of this plot. This will serve as a baseline against which to compare the effects of tuning the trading algorithm.

8. Write your conclusions about the performance of the baseline trading algorithm in the `README.md` file that’s associated with your GitHub repository. Support your findings by using the PNG image that you saved in the previous step.

#### Tune the Baseline Trading Algorithm

In this section, you’ll tune, or adjust, the model’s input features to find the parameters that result in the best trading outcomes. (You’ll choose the best by comparing the cumulative products of the strategy returns.) To do so, complete the following steps:

1. Tune the training algorithm by adjusting the size of the training dataset. To do so, slice your data into different periods. Rerun the notebook with the updated parameters, and record the results in your `README.md` file. Answer the following question: What impact resulted from increasing or decreasing the training window?

> **Hint** To adjust the size of the training dataset, you can use a different `DateOffset` value&mdash;for example, six months. Be aware that changing the size of the training dataset also affects the size of the testing dataset.

2. Tune the trading algorithm by adjusting the SMA input features. Adjust one or both of the windows for the algorithm. Rerun the notebook with the updated parameters, and record the results in your `README.md` file. Answer the following question: What impact resulted from increasing or decreasing either or both of the SMA windows?

3. Choose the set of parameters that best improved the trading algorithm returns. Save a PNG image of the cumulative product of the actual returns vs. the strategy returns, and document your conclusion in your `README.md` file.

#### Evaluate a New Machine Learning Classifier

In this section, you’ll use the original parameters that the starter code provided. But, you’ll apply them to the performance of a second machine learning model. To do so, complete the following steps:

1. Import a new classifier, such as `AdaBoost`, `DecisionTreeClassifier`, or `LogisticRegression`. (For the full list of classifiers, refer to the [Supervised learning page](https://scikit-learn.org/stable/supervised_learning.html) in the scikit-learn documentation.)

2. Using the original training data as the baseline model, fit another model with the new classifier.

3. Backtest the new model to evaluate its performance. Save a PNG image of the cumulative product of the actual returns vs. the strategy returns for this updated trading algorithm, and write your conclusions in your `README.md` file. Answer the following questions: Did this new model perform better or worse than the provided baseline model? Did this new model perform better or worse than your tuned trading algorithm?

#### Create an Evaluation Report

In the previous sections, you updated your `README.md` file with your conclusions. To accomplish this section, you need to add a summary evaluation report at the end of the `README.md` file. For this report, express your final conclusions and analysis. Support your findings by using the PNG images that you created.



```python
# Imports
import pandas as pd
import numpy as np
from pathlib import Path
import hvplot.pandas
import matplotlib.pyplot as plt
from sklearn import svm
from sklearn.preprocessing import StandardScaler
from pandas.tseries.offsets import DateOffset
from sklearn.metrics import classification_report
```









---

## Establish a Baseline Performance

In this section, you’ll run the provided starter code to establish a baseline performance for the trading algorithm. To do so, complete the following steps.

Open the Jupyter notebook. Restart the kernel, run the provided cells that correspond with the first three steps, and then proceed to step four. 


### Step 1: mport the OHLCV dataset into a Pandas DataFrame.


```python
# Import the OHLCV dataset into a Pandas Dataframe
ohlcv_df = pd.read_csv(
    Path("./Resources/emerging_markets_ohlcv.csv"), 
    index_col='date', 
    infer_datetime_format=True, 
    parse_dates=True
)

# Review the DataFrame
ohlcv_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>open</th>
      <th>high</th>
      <th>low</th>
      <th>close</th>
      <th>volume</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-01-21 09:30:00</th>
      <td>23.83</td>
      <td>23.83</td>
      <td>23.83</td>
      <td>23.83</td>
      <td>100</td>
    </tr>
    <tr>
      <th>2015-01-21 11:00:00</th>
      <td>23.98</td>
      <td>23.98</td>
      <td>23.98</td>
      <td>23.98</td>
      <td>100</td>
    </tr>
    <tr>
      <th>2015-01-22 15:00:00</th>
      <td>24.42</td>
      <td>24.42</td>
      <td>24.42</td>
      <td>24.42</td>
      <td>100</td>
    </tr>
    <tr>
      <th>2015-01-22 15:15:00</th>
      <td>24.42</td>
      <td>24.44</td>
      <td>24.42</td>
      <td>24.44</td>
      <td>200</td>
    </tr>
    <tr>
      <th>2015-01-22 15:30:00</th>
      <td>24.46</td>
      <td>24.46</td>
      <td>24.46</td>
      <td>24.46</td>
      <td>200</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Filter the date index and close columns
signals_df = ohlcv_df.loc[:, ["close"]]

# Use the pct_change function to generate  returns from close prices
signals_df["Actual Returns"] = signals_df["close"].pct_change()

# Drop all NaN values from the DataFrame
signals_df = signals_df.dropna()

# Review the DataFrame
display(signals_df.head())
display(signals_df.tail())
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>close</th>
      <th>Actual Returns</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-01-21 11:00:00</th>
      <td>23.98</td>
      <td>0.006295</td>
    </tr>
    <tr>
      <th>2015-01-22 15:00:00</th>
      <td>24.42</td>
      <td>0.018349</td>
    </tr>
    <tr>
      <th>2015-01-22 15:15:00</th>
      <td>24.44</td>
      <td>0.000819</td>
    </tr>
    <tr>
      <th>2015-01-22 15:30:00</th>
      <td>24.46</td>
      <td>0.000818</td>
    </tr>
    <tr>
      <th>2015-01-26 12:30:00</th>
      <td>24.33</td>
      <td>-0.005315</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>close</th>
      <th>Actual Returns</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2021-01-22 09:30:00</th>
      <td>33.27</td>
      <td>-0.006866</td>
    </tr>
    <tr>
      <th>2021-01-22 11:30:00</th>
      <td>33.35</td>
      <td>0.002405</td>
    </tr>
    <tr>
      <th>2021-01-22 13:45:00</th>
      <td>33.42</td>
      <td>0.002099</td>
    </tr>
    <tr>
      <th>2021-01-22 14:30:00</th>
      <td>33.47</td>
      <td>0.001496</td>
    </tr>
    <tr>
      <th>2021-01-22 15:45:00</th>
      <td>33.44</td>
      <td>-0.000896</td>
    </tr>
  </tbody>
</table>
</div>


## Step 2: Generate trading signals using short- and long-window SMA values. 


```python
# Set the short window and long window
short_window = 4
long_window = 100

# Generate the fast and slow simple moving averages (4 and 100 days, respectively)
signals_df['SMA_Fast'] = signals_df['close'].rolling(window=short_window).mean()
signals_df['SMA_Slow'] = signals_df['close'].rolling(window=long_window).mean()

signals_df = signals_df.dropna()

# Review the DataFrame
display(signals_df.head())
display(signals_df.tail())
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>close</th>
      <th>Actual Returns</th>
      <th>SMA_Fast</th>
      <th>SMA_Slow</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-04-02 14:45:00</th>
      <td>24.92</td>
      <td>0.000000</td>
      <td>24.9175</td>
      <td>24.3214</td>
    </tr>
    <tr>
      <th>2015-04-02 15:00:00</th>
      <td>24.92</td>
      <td>0.000000</td>
      <td>24.9200</td>
      <td>24.3308</td>
    </tr>
    <tr>
      <th>2015-04-02 15:15:00</th>
      <td>24.94</td>
      <td>0.000803</td>
      <td>24.9250</td>
      <td>24.3360</td>
    </tr>
    <tr>
      <th>2015-04-02 15:30:00</th>
      <td>24.95</td>
      <td>0.000401</td>
      <td>24.9325</td>
      <td>24.3411</td>
    </tr>
    <tr>
      <th>2015-04-02 15:45:00</th>
      <td>24.98</td>
      <td>0.001202</td>
      <td>24.9475</td>
      <td>24.3463</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>close</th>
      <th>Actual Returns</th>
      <th>SMA_Fast</th>
      <th>SMA_Slow</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2021-01-22 09:30:00</th>
      <td>33.27</td>
      <td>-0.006866</td>
      <td>33.2025</td>
      <td>30.40215</td>
    </tr>
    <tr>
      <th>2021-01-22 11:30:00</th>
      <td>33.35</td>
      <td>0.002405</td>
      <td>33.2725</td>
      <td>30.44445</td>
    </tr>
    <tr>
      <th>2021-01-22 13:45:00</th>
      <td>33.42</td>
      <td>0.002099</td>
      <td>33.3850</td>
      <td>30.48745</td>
    </tr>
    <tr>
      <th>2021-01-22 14:30:00</th>
      <td>33.47</td>
      <td>0.001496</td>
      <td>33.3775</td>
      <td>30.53085</td>
    </tr>
    <tr>
      <th>2021-01-22 15:45:00</th>
      <td>33.44</td>
      <td>-0.000896</td>
      <td>33.4200</td>
      <td>30.57495</td>
    </tr>
  </tbody>
</table>
</div>



```python
# Initialize the new Signal column
signals_df['Signal'] = 0.0

# When Actual Returns are greater than or equal to 0, generate signal to buy stock long
signals_df.loc[(signals_df['Actual Returns'] >= 0), 'Signal'] = 1

# When Actual Returns are less than 0, generate signal to sell stock short
signals_df.loc[(signals_df['Actual Returns'] < 0), 'Signal'] = -1

# Review the DataFrame
display(signals_df.head())
display(signals_df.tail())
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>close</th>
      <th>Actual Returns</th>
      <th>SMA_Fast</th>
      <th>SMA_Slow</th>
      <th>Signal</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-04-02 14:45:00</th>
      <td>24.92</td>
      <td>0.000000</td>
      <td>24.9175</td>
      <td>24.3214</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2015-04-02 15:00:00</th>
      <td>24.92</td>
      <td>0.000000</td>
      <td>24.9200</td>
      <td>24.3308</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2015-04-02 15:15:00</th>
      <td>24.94</td>
      <td>0.000803</td>
      <td>24.9250</td>
      <td>24.3360</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2015-04-02 15:30:00</th>
      <td>24.95</td>
      <td>0.000401</td>
      <td>24.9325</td>
      <td>24.3411</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2015-04-02 15:45:00</th>
      <td>24.98</td>
      <td>0.001202</td>
      <td>24.9475</td>
      <td>24.3463</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>close</th>
      <th>Actual Returns</th>
      <th>SMA_Fast</th>
      <th>SMA_Slow</th>
      <th>Signal</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2021-01-22 09:30:00</th>
      <td>33.27</td>
      <td>-0.006866</td>
      <td>33.2025</td>
      <td>30.40215</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>2021-01-22 11:30:00</th>
      <td>33.35</td>
      <td>0.002405</td>
      <td>33.2725</td>
      <td>30.44445</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2021-01-22 13:45:00</th>
      <td>33.42</td>
      <td>0.002099</td>
      <td>33.3850</td>
      <td>30.48745</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2021-01-22 14:30:00</th>
      <td>33.47</td>
      <td>0.001496</td>
      <td>33.3775</td>
      <td>30.53085</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2021-01-22 15:45:00</th>
      <td>33.44</td>
      <td>-0.000896</td>
      <td>33.4200</td>
      <td>30.57495</td>
      <td>-1.0</td>
    </tr>
  </tbody>
</table>
</div>



```python
signals_df['Signal'].value_counts()
```




     1.0    2368
    -1.0    1855
    Name: Signal, dtype: int64




```python
# Calculate the strategy returns and add them to the signals_df DataFrame
signals_df['Strategy Returns'] = signals_df['Actual Returns'] * signals_df['Signal'].shift()

# Review the DataFrame
display(signals_df.head())
display(signals_df.tail())
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>close</th>
      <th>Actual Returns</th>
      <th>SMA_Fast</th>
      <th>SMA_Slow</th>
      <th>Signal</th>
      <th>Strategy Returns</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-04-02 14:45:00</th>
      <td>24.92</td>
      <td>0.000000</td>
      <td>24.9175</td>
      <td>24.3214</td>
      <td>1.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2015-04-02 15:00:00</th>
      <td>24.92</td>
      <td>0.000000</td>
      <td>24.9200</td>
      <td>24.3308</td>
      <td>1.0</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>2015-04-02 15:15:00</th>
      <td>24.94</td>
      <td>0.000803</td>
      <td>24.9250</td>
      <td>24.3360</td>
      <td>1.0</td>
      <td>0.000803</td>
    </tr>
    <tr>
      <th>2015-04-02 15:30:00</th>
      <td>24.95</td>
      <td>0.000401</td>
      <td>24.9325</td>
      <td>24.3411</td>
      <td>1.0</td>
      <td>0.000401</td>
    </tr>
    <tr>
      <th>2015-04-02 15:45:00</th>
      <td>24.98</td>
      <td>0.001202</td>
      <td>24.9475</td>
      <td>24.3463</td>
      <td>1.0</td>
      <td>0.001202</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>close</th>
      <th>Actual Returns</th>
      <th>SMA_Fast</th>
      <th>SMA_Slow</th>
      <th>Signal</th>
      <th>Strategy Returns</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2021-01-22 09:30:00</th>
      <td>33.27</td>
      <td>-0.006866</td>
      <td>33.2025</td>
      <td>30.40215</td>
      <td>-1.0</td>
      <td>-0.006866</td>
    </tr>
    <tr>
      <th>2021-01-22 11:30:00</th>
      <td>33.35</td>
      <td>0.002405</td>
      <td>33.2725</td>
      <td>30.44445</td>
      <td>1.0</td>
      <td>-0.002405</td>
    </tr>
    <tr>
      <th>2021-01-22 13:45:00</th>
      <td>33.42</td>
      <td>0.002099</td>
      <td>33.3850</td>
      <td>30.48745</td>
      <td>1.0</td>
      <td>0.002099</td>
    </tr>
    <tr>
      <th>2021-01-22 14:30:00</th>
      <td>33.47</td>
      <td>0.001496</td>
      <td>33.3775</td>
      <td>30.53085</td>
      <td>1.0</td>
      <td>0.001496</td>
    </tr>
    <tr>
      <th>2021-01-22 15:45:00</th>
      <td>33.44</td>
      <td>-0.000896</td>
      <td>33.4200</td>
      <td>30.57495</td>
      <td>-1.0</td>
      <td>-0.000896</td>
    </tr>
  </tbody>
</table>
</div>



```python
# Plot Strategy Returns to examine performance
(1 + signals_df['Strategy Returns']).cumprod().plot()
```




    <AxesSubplot:xlabel='date'>




    
![png](output_11_1.png)
    


### Step 3: Split the data into training and testing datasets.


```python
# Assign a copy of the sma_fast and sma_slow columns to a features DataFrame called X
X = signals_df[['SMA_Fast', 'SMA_Slow']].shift().dropna()

# Review the DataFrame
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SMA_Fast</th>
      <th>SMA_Slow</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-04-02 15:00:00</th>
      <td>24.9175</td>
      <td>24.3214</td>
    </tr>
    <tr>
      <th>2015-04-02 15:15:00</th>
      <td>24.9200</td>
      <td>24.3308</td>
    </tr>
    <tr>
      <th>2015-04-02 15:30:00</th>
      <td>24.9250</td>
      <td>24.3360</td>
    </tr>
    <tr>
      <th>2015-04-02 15:45:00</th>
      <td>24.9325</td>
      <td>24.3411</td>
    </tr>
    <tr>
      <th>2015-04-06 09:30:00</th>
      <td>24.9475</td>
      <td>24.3463</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Create the target set selecting the Signal column and assiging it to y
y = signals_df['Signal']

# Review the value counts
y.value_counts()
```




     1.0    2368
    -1.0    1855
    Name: Signal, dtype: int64




```python
# Select the start of the training period
training_begin = X.index.min()

# Display the training begin date
print(training_begin)
```

    2015-04-02 15:00:00
    


```python
# Select the ending period for the training data with an offset of 3 months
training_end = X.index.min() + DateOffset(months=3)

# Display the training end date
print(training_end)
```

    2015-07-02 15:00:00
    


```python
# Generate the X_train and y_train DataFrames
X_train = X.loc[training_begin:training_end]
y_train = y.loc[training_begin:training_end]

# Review the X_train DataFrame
X_train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SMA_Fast</th>
      <th>SMA_Slow</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-04-02 15:00:00</th>
      <td>24.9175</td>
      <td>24.3214</td>
    </tr>
    <tr>
      <th>2015-04-02 15:15:00</th>
      <td>24.9200</td>
      <td>24.3308</td>
    </tr>
    <tr>
      <th>2015-04-02 15:30:00</th>
      <td>24.9250</td>
      <td>24.3360</td>
    </tr>
    <tr>
      <th>2015-04-02 15:45:00</th>
      <td>24.9325</td>
      <td>24.3411</td>
    </tr>
    <tr>
      <th>2015-04-06 09:30:00</th>
      <td>24.9475</td>
      <td>24.3463</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Generate the X_test and y_test DataFrames
X_test = X.loc[training_end+DateOffset(hours=1):]
y_test = y.loc[training_end+DateOffset(hours=1):]

# Review the X_test DataFrame
display(X_test.count())
X_test
```


    SMA_Fast    4092
    SMA_Slow    4092
    dtype: int64





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SMA_Fast</th>
      <th>SMA_Slow</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-07-06 10:00:00</th>
      <td>24.1250</td>
      <td>25.09190</td>
    </tr>
    <tr>
      <th>2015-07-06 10:45:00</th>
      <td>23.9700</td>
      <td>25.06820</td>
    </tr>
    <tr>
      <th>2015-07-06 14:15:00</th>
      <td>23.8475</td>
      <td>25.04580</td>
    </tr>
    <tr>
      <th>2015-07-06 14:30:00</th>
      <td>23.6725</td>
      <td>25.02060</td>
    </tr>
    <tr>
      <th>2015-07-07 11:30:00</th>
      <td>23.4800</td>
      <td>24.99510</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2021-01-22 09:30:00</th>
      <td>33.1725</td>
      <td>30.36035</td>
    </tr>
    <tr>
      <th>2021-01-22 11:30:00</th>
      <td>33.2025</td>
      <td>30.40215</td>
    </tr>
    <tr>
      <th>2021-01-22 13:45:00</th>
      <td>33.2725</td>
      <td>30.44445</td>
    </tr>
    <tr>
      <th>2021-01-22 14:30:00</th>
      <td>33.3850</td>
      <td>30.48745</td>
    </tr>
    <tr>
      <th>2021-01-22 15:45:00</th>
      <td>33.3775</td>
      <td>30.53085</td>
    </tr>
  </tbody>
</table>
<p>4092 rows × 2 columns</p>
</div>




```python
# Scale the features DataFrames

# Create a StandardScaler instance
scaler = StandardScaler()

# Apply the scaler model to fit the X-train data
X_scaler = scaler.fit(X_train)

# Transform the X_train and X_test DataFrames using the X_scaler
X_train_scaled = X_scaler.transform(X_train)
X_test_scaled = X_scaler.transform(X_test)
```

### Step 4: Use the `SVC` classifier model from SKLearn's support vector machine (SVM) learning method to fit the training data and make predictions based on the testing data. Review the predictions.


```python
# From SVM, instantiate SVC classifier model instance
svm_model = svm.SVC()
 
# Fit the model to the data using the training data
svm_model = svm_model.fit(X_train_scaled, y_train)
 
# Use the testing data to make the model predictions
svm_pred = svm_model.predict(X_test_scaled)

# Review the model's predicted values
svm_pred[:10]

```




    array([1., 1., 1., 1., 1., 1., 1., 1., 1., 1.])



### Step 5: Review the classification report associated with the `SVC` model predictions. 


```python
# Use a classification report to evaluate the model using the predictions and testing data
svm_testing_report = classification_report(y_test, svm_pred)

# Print the classification report
print(svm_testing_report)

```

                  precision    recall  f1-score   support
    
            -1.0       0.43      0.04      0.07      1804
             1.0       0.56      0.96      0.71      2288
    
        accuracy                           0.55      4092
       macro avg       0.49      0.50      0.39      4092
    weighted avg       0.50      0.55      0.43      4092
    
    

### Step 6: Create a predictions DataFrame that contains columns for “Predicted” values, “Actual Returns”, and “Strategy Returns”.


```python
# Create a new empty predictions DataFrame.

# Create a predictions DataFrame
predictions_df = pd.DataFrame(index=X_test.index)

# Add the SVM model predictions to the DataFrame
predictions_df['Predicted'] = svm_pred
predictions_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Predicted</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-07-06 10:00:00</th>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2015-07-06 10:45:00</th>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2015-07-06 14:15:00</th>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2015-07-06 14:30:00</th>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2015-07-07 11:30:00</th>
      <td>1.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>2021-01-22 09:30:00</th>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2021-01-22 11:30:00</th>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2021-01-22 13:45:00</th>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2021-01-22 14:30:00</th>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2021-01-22 15:45:00</th>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
<p>4092 rows × 1 columns</p>
</div>




```python
# Add the actual returns to the DataFrame
predictions_df['Actual Returns'] = signals_df['Actual Returns']

# Add the strategy returns to the DataFrame
predictions_df['Strategy Returns'] = (
    predictions_df['Actual Returns'] * predictions_df['Predicted']
)

# Review the DataFrame
display(predictions_df.head())
display(predictions_df.tail())
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Predicted</th>
      <th>Actual Returns</th>
      <th>Strategy Returns</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-07-06 10:00:00</th>
      <td>1.0</td>
      <td>-0.025715</td>
      <td>-0.025715</td>
    </tr>
    <tr>
      <th>2015-07-06 10:45:00</th>
      <td>1.0</td>
      <td>0.007237</td>
      <td>0.007237</td>
    </tr>
    <tr>
      <th>2015-07-06 14:15:00</th>
      <td>1.0</td>
      <td>-0.009721</td>
      <td>-0.009721</td>
    </tr>
    <tr>
      <th>2015-07-06 14:30:00</th>
      <td>1.0</td>
      <td>-0.003841</td>
      <td>-0.003841</td>
    </tr>
    <tr>
      <th>2015-07-07 11:30:00</th>
      <td>1.0</td>
      <td>-0.018423</td>
      <td>-0.018423</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Predicted</th>
      <th>Actual Returns</th>
      <th>Strategy Returns</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2021-01-22 09:30:00</th>
      <td>1.0</td>
      <td>-0.006866</td>
      <td>-0.006866</td>
    </tr>
    <tr>
      <th>2021-01-22 11:30:00</th>
      <td>1.0</td>
      <td>0.002405</td>
      <td>0.002405</td>
    </tr>
    <tr>
      <th>2021-01-22 13:45:00</th>
      <td>1.0</td>
      <td>0.002099</td>
      <td>0.002099</td>
    </tr>
    <tr>
      <th>2021-01-22 14:30:00</th>
      <td>1.0</td>
      <td>0.001496</td>
      <td>0.001496</td>
    </tr>
    <tr>
      <th>2021-01-22 15:45:00</th>
      <td>1.0</td>
      <td>-0.000896</td>
      <td>-0.000896</td>
    </tr>
  </tbody>
</table>
</div>


### Step 7: Create a cumulative return plot that shows the actual returns vs. the strategy returns. Save a PNG image of this plot. This will serve as a baseline against which to compare the effects of tuning the trading algorithm.


```python
# Plot the actual returns versus the strategy returns
(1 + predictions_df[["Actual Returns", "Strategy Returns"]]).cumprod().plot()

```




    <AxesSubplot:xlabel='date'>




    
![png](output_28_1.png)
    


---

## Tune the Baseline Trading Algorithm

## Step 6: Use an Alternative ML Model and Evaluate Strategy Returns

In this section, you’ll tune, or adjust, the model’s input features to find the parameters that result in the best trading outcomes. You’ll choose the best by comparing the cumulative products of the strategy returns.

### Step 1: Tune the training algorithm by adjusting the size of the training dataset. 

To do so, slice your data into different periods. Rerun the notebook with the updated parameters, and record the results in your `README.md` file. 

Answer the following question: What impact resulted from increasing or decreasing the training window?

### Step 2: Tune the trading algorithm by adjusting the SMA input features. 

Adjust one or both of the windows for the algorithm. Rerun the notebook with the updated parameters, and record the results in your `README.md` file. 

Answer the following question: What impact resulted from increasing or decreasing either or both of the SMA windows?

### Step 3: Choose the set of parameters that best improved the trading algorithm returns. 

Save a PNG image of the cumulative product of the actual returns vs. the strategy returns, and document your conclusion in your `README.md` file.

---

## Evaluate a New Machine Learning Classifier

In this section, you’ll use the original parameters that the starter code provided. But, you’ll apply them to the performance of a second machine learning model. 

### Step 1:  Import a new classifier, such as `AdaBoost`, `DecisionTreeClassifier`, or `LogisticRegression`. (For the full list of classifiers, refer to the [Supervised learning page](https://scikit-learn.org/stable/supervised_learning.html) in the scikit-learn documentation.)


```python
# Import a new classifier from SKLearn
from sklearn.linear_model import LogisticRegression
# Initiate the model instance
logistic_regression_model = LogisticRegression()

```

### Step 2: Using the original training data as the baseline model, fit another model with the new classifier.


```python
# Fit the model using the training data
model = logistic_regression_model.fit(X_train_scaled, y_train)

# Use the testing dataset to generate the predictions for the new model
pred = logistic_regression_model.predict(X_test_scaled)

# Review the model's predicted values
pred[:10]

```




    array([1., 1., 1., 1., 1., 1., 1., 1., 1., 1.])



### Step 3: Backtest the new model to evaluate its performance. 

Save a PNG image of the cumulative product of the actual returns vs. the strategy returns for this updated trading algorithm, and write your conclusions in your `README.md` file. 

Answer the following questions: 
Did this new model perform better or worse than the provided baseline model? 
Did this new model perform better or worse than your tuned trading algorithm?


```python
# Use a classification report to evaluate the model using the predictions and testing data
testing_report = classification_report(y_test, pred)

# Print the classification report
print(testing_report)

```

                  precision    recall  f1-score   support
    
            -1.0       0.44      0.33      0.38      1804
             1.0       0.56      0.66      0.61      2288
    
        accuracy                           0.52      4092
       macro avg       0.50      0.50      0.49      4092
    weighted avg       0.51      0.52      0.51      4092
    
    


```python
# Create a new empty predictions DataFrame.

# Create a predictions DataFrame
predictions2_df = pd.DataFrame(index=X_test.index)

# Add the SVM model predictions to the DataFrame
predictions2_df["Predicted"] = pred

# Add the actual returns to the DataFrame
predictions2_df["Actual Returns"] = signals_df["Actual Returns"]

# Add the strategy returns to the DataFrame
predictions2_df["Strategy Returns"] = (
    predictions2_df["Actual Returns"] * predictions2_df["Predicted"]
)

# Review the DataFrame
display(predictions2_df.head())
display(predictions2_df.tail())
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Predicted</th>
      <th>Actual Returns</th>
      <th>Strategy Returns</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-07-06 10:00:00</th>
      <td>1.0</td>
      <td>-0.025715</td>
      <td>-0.025715</td>
    </tr>
    <tr>
      <th>2015-07-06 10:45:00</th>
      <td>1.0</td>
      <td>0.007237</td>
      <td>0.007237</td>
    </tr>
    <tr>
      <th>2015-07-06 14:15:00</th>
      <td>1.0</td>
      <td>-0.009721</td>
      <td>-0.009721</td>
    </tr>
    <tr>
      <th>2015-07-06 14:30:00</th>
      <td>1.0</td>
      <td>-0.003841</td>
      <td>-0.003841</td>
    </tr>
    <tr>
      <th>2015-07-07 11:30:00</th>
      <td>1.0</td>
      <td>-0.018423</td>
      <td>-0.018423</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Predicted</th>
      <th>Actual Returns</th>
      <th>Strategy Returns</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2021-01-22 09:30:00</th>
      <td>-1.0</td>
      <td>-0.006866</td>
      <td>0.006866</td>
    </tr>
    <tr>
      <th>2021-01-22 11:30:00</th>
      <td>-1.0</td>
      <td>0.002405</td>
      <td>-0.002405</td>
    </tr>
    <tr>
      <th>2021-01-22 13:45:00</th>
      <td>-1.0</td>
      <td>0.002099</td>
      <td>-0.002099</td>
    </tr>
    <tr>
      <th>2021-01-22 14:30:00</th>
      <td>-1.0</td>
      <td>0.001496</td>
      <td>-0.001496</td>
    </tr>
    <tr>
      <th>2021-01-22 15:45:00</th>
      <td>-1.0</td>
      <td>-0.000896</td>
      <td>0.000896</td>
    </tr>
  </tbody>
</table>
</div>



```python
# Plot the actual returns versus the strategy returns
(1 + predictions2_df[["Actual Returns", "Strategy Returns"]]).cumprod().plot()
```




    <AxesSubplot:xlabel='date'>




    
![png](output_43_1.png)
    

